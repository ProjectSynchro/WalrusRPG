package eplus.network.proxies;

/**
 * @user odininon
 * @license Lesser GNU Public License v3 (http://www.gnu.org/licenses/lgpl.html)
 */
public class CommonProxy
{
    public void registerTickHandlers()
    {
    }

    public void throwFingerprintError(String s)
    {
    }

    public void registerEnchantments()
    {
    }
}
