package eplus.lib;

/**
 * Enchanting Plus
 * 
 * @user odininon
 * @license Lesser GNU Public License v3 (http://www.gnu.org/licenses/lgpl.html)
 */

public class References
{
    public static final String MODNAME = "Enchanting Plus";
    public static final String MODID = "eplus";

    public static final String FINGERPRINT = "@FINGERPRINT@";
}
