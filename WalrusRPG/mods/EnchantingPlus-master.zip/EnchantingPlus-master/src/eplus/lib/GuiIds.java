package eplus.lib;

/**
 * Enchanting Plus
 * 
 * @user odininon
 * @license Lesser GNU Public License v3 (http://www.gnu.org/licenses/lgpl.html)
 */

public class GuiIds
{
    public static final int ModTable = 0;
    public static final int VanillaTable = 1;

}
