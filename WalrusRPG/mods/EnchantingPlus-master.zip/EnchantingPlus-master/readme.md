Enchanting Plus
===============
This mod completely gets rid of the randomness of enchanting and allows you to pick what YOU want on your tools!
 It is. It will register enchantments that other mods add and will show up for the appropriate tool.